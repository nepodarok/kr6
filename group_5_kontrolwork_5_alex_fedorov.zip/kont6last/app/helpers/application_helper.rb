module ApplicationHelper
  def all_categories
    Category.all
  end
end
